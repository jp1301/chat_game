"""A collection of function for doing my project."""

import random

#Gives initial instructions and introduction

def instructions():
    """Prints out the initial instructions and gives an introduction to the game"""
    
    output = print('\033[1mPlease no CAPLOCKS we can hear you \n')
    print('\033[44m\033[1mThis is a simulation of a short soccer tournament based on your nationality and some quiz questions')
    print('Each answer you get correct will be a goal, you need to beat the other team by at least 2 goals to advance to your next opponent')
    print('You are only allowd to make 1 spelling error, otherwise, you will be assigned a random choice, thanks for playing, good luck, and have fun!')
    print('\033[4m')
    
    return output

def input_team():
    """asks user for nationality to select their team"""
    
    team_name = input('\033[1m\033[41mWhat nationality are you? :\t')
    
    #Check to see that the input is an actual name of nation
    if team_name in world_nations:
        team_name = team_name.capitalize()
        print('You are now the', team_name, 'team manager')
        team_name = False
        
    # Checks if input is in top 10 of FIFA 
    elif team_name in nations_top: 
        team_name = team_name
        top_team = print('You are the manager of the', team_name, 'team')
        team_name = True
        
    # If input something other than desired, reassigns variable 
    else:
        team_name = None
        print('Please enter a real nation')
        
    return team_name

def change_team():
    """asks if user wants to chance teams"""
    
    #takes in new input and assigns it to new variable
    team_change = input('\033[41m\033[1mAlright, alright I will let you slide this time, do you want to change your nationality?(yes or no) :\t')
    
    return team_change

def input_jersey():
    """user inputs their preference in jersey"""
    
    jersey = input('\033[41m\033[1mHome or away Jersey? :\t')
    
    if jersey not in jersey_choice:
        jersey = False
        print('\033[44m\033[1mchoose home or away')
        
    return jersey

def side(jersey):
    """sets user against 1st opponent based on jersey"""
    
    if jersey == 'home':
        print('\033[42m\033[1mYou will be playing against Trap United')
        print('\033[42m\033[1mNow that that is sorted out, you will play your games, you have to win the first game to advanced to the second')
        
    else:
        print('\033[42m\033[1mYou will be playing against SHPE FC')
        
    return jersey


def first_game():
    """will play against one of the opponents"""
    
    while True:
        #starts of with the score at 0 and adds 1 everytime a question is answered wrong
        score_count = 0
        
        q1 = input('\033[41m\033[1mWho won the 2010 World Cup?: a) Mexico b) USA c) Holand d) Spain? (type a letter) :\t')
        if q1 == 'd':
            print('\033[43m\033[1mCorrect onto the next question,')
        else:
            print('\033[42m\033[1mThats one wrong, another and you will be out of the tournament')
            score_count = score_count + 1
            
        q2 = input('\033[41m\033[1mThe next World Cup is going to be hosted in the US (true or false) :\t')
        if q2 == 'false':
            print('\033[43m\033[1mCorrect onto the next question')
        else:
            print('\033[42m\033[1mThats wrong, your game might be over')
            score_count = score_count + 1
            
        q3 = input('\033[41m\033[1mHow many World Cups does the US have? (type a number) :\t')
        if q3 == '0':
            print('\033[43m\033[1mCorrect')
        else:
            print('\033[42m\033[1mThats wrong your game might be over')
            score_count = score_count + 1
        
        #If the user answers 2 or more questions wrong the game ends
        if score_count >= 2:
            print('\033[44m\033[1mYou got',score_count,'answers wrong, therefore you were eliminated, now the System will now EXIT, but thanks for playing')
            
            raise SystemExit
            
        break

    return q1, q2, q3

def second_game():
    """will play against one of the opponents"""
    
    #Does the same as in first_game but with different questions
    while True:
        score_count = 0
        
        q1 = input('\033[41m\033[1mWho was the runner-up in 2018 World Cup?: a) Mexico b) USA c) Croatia d) Spain? (type a letter) :\t')
        if q1 == 'c':
            print('\033[43m\033[1mCorrect onto the next question,')
        else:
            print('\033[42m\033[1mThats one wrong, another and you will be out of the tournament')
            score_count = score_count + 1
            
        q2 = input('\033[41m\033[1mStatistics say that Messi is the best in the world (true or false) :\t')
        if q2 == 'true':
            print('\033[43m\033[1mCorrect onto the next question')
        else:
            print('\033[42m\033[1mThats wrong, your game might be over')
            score_count = score_count + 1
            
        q3 = input('\033[41m\033[1mHow many goals does Messi have in World Cup finals? (type a number) :\t')
        if q3 == '0':
            print('\033[43m\033[1mCorrect')
        else:
            print('\033[42m\033[1mThats wrong your game is over, but keep playing or play again for fun')
            score_count = score_count + 1
            
        if score_count >=2:
            print('\033[44m\033[1mYou got',score_count,'answers wrong, therefore you were eliminated, now the System will now EXIT, but thanks for playing')
            
            raise SystemExit
            
        break

    return q1, q2, q3


def special_game():
    """Will allow user to skip to here if nation within top 10"""
    
    #Only accessible at begining of game, its due or die, user must play along
    print('\033[1mCongratulations your team is within top 10 in the world')
    print('You will only need to answer 1 question to win')
    
    qs = input('What is the name of last years Ballon d Or winner? :\t')
    
    if qs == 'modric':
        print('Correct, You win, the game will now exit')
        raise SystemExit
    else:
        print('Too bad, it was all or nothing you lose :p')
        raise SystemExit
        
    return qs







