"""Test for my functions.

Note: because these are 'empty' functions (return None), here we just test
  that the functions execute, and return None, as expected.
"""

from my_module.chat_game import instructions
from my_module.chat_game import input_team
from my_module.chat_game import change_team
from my_module.chat_game import input_jersey
from my_module.chat_game import side
from my_module.chat_game import first_game
from my_module.chat_game import second_game
from my_module.chat_game import special_game 

##
##

def test_instructions():

    assert instructions () == None

def test_input_team():

    assert input_team () == None
    
def test_change_team():
    
    assert isinstance(change_team, str)
    
def test_input_jersey():
    
    assert isinstance(input_jersey(), str)
    
def test_side():
    
    assert 
    
    
    
    
    
    
