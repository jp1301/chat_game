"""Script to run some part of my project."""

# This adds the directory above to our Python path
#   This is so that we can add import our custom python module code into this script
import sys
sys.path.append('../')

# Imports
import random

from my_module.chat_game import instructions
from my_module.chat_game import input_team
from my_module.chat_game import change_team
from my_module.chat_game import input_jersey
from my_module.chat_game import side
from my_module.chat_game import first_game
from my_module.chat_game import second_game
from my_module.chat_game import special_game 

nations_top = ['belgian','french', 'brazilian', 'british', 'croatian', 'uruguayan', 'portuguese', 'swiss', 'spanish', 'danish']

#data from: https://gist.github.com/zamai/8e0d30a7f23f33e9c220c20db71c80dc
world_nations = ['afghan', 'albanian', 'algerian', 'american', 'andorran', 'angolan', 'antiguans', 'argentinean', 'armenian', 'australian', 'austrian', 'azerbaijani', 'bahamian', 'bahraini', 'bangladeshi', 'barbadian', 'barbudans', 'batswana', 'belarusian', 'belizean', 'beninese', 'bhutanese', 'bolivian', 'bosnian', 'bruneian', 'bulgarian', 'burkinabe', 'burmese', 'burundian', 'cambodian', 'cameroonian', 'canadian', 'cape verdean', 'central african', 'chadian', 'chilean', 'chinese', 'colombian', 'comoran',  'congolese', 'costa rican', 'cuban', 'cypriot', 'czech', 'djibouti', 'dominican', 'dutch', 'dutchman', 'dutchwoman', 'east timorese', 'ecuadorean', 'egyptian', 'emirian', 'equatorial guinean', 'eritrean', 'estonian', 'ethiopian', 'fijian', 'filipino', 'finnish', 'gabonese', 'gambian', 'georgian', 'german', 'ghanaian', 'greek', 'grenadian', 'guatemalan', 'guinea-bissauan', 'guinean', 'guyanese', 'haitian', 'herzegovinian', 'honduran', 'hungarian', 'i-kiribati', 'icelander', 'indian', 'indonesian', 'iranian', 'iraqi', 'irish', 'israeli', 'italian', 'ivorian', 'jiamaican', 'japanese', 'jordanian', 'kazakhstani', 'kenyan', 'kittian and nevisian','korean', 'kuwaiti', 'kyrgyz', 'laotian', 'latvian', 'lebanese', 'liberian', 'libyan', 'liechtensteiner', 'lithuanian', 'luxembourger', 'macedonian', 'malagasy', 'malawian', 'malaysian', 'maldivan', 'malian', 'maltese', 'marshallese', 'mauritanian', 'mauritian', 'mexican', 'micronesian', 'moldovan', 'monacan', 'mongolian', 'moroccan', 'momsotho', 'motswana', 'mozambican', 'namibian', 'nauruan', 'nepalese', 'netherlander', 'new zealander', 'niv-vanuatu', 'nicaraguan', 'nigerian', 'nigerien', 'north korean', 'northern irish', 'norwegian', 'omani', 'pakistani', 'palauan', 'panamanian', 'papua new guinean', 'paraguayan', 'peruvian', 'polish', 'qatari', 'romanian', 'russian', 'rwandan', 'saint lucian', 'salvadoran', 'samoan', 'san marinese', 'sao tomean', 'saudi', 'scottish', 'senegalese', 'serbian', 'seychellois', 'sierra leonean', 'singaporean', 'slovakian', 'slovenian', 'solomon islander', 'somali', 'south african', 'south korean', 'sri lankan', 'sudanese', 'surinamer', 'swazi', 'swedish', 'syrian', 'taiwanese', 'tajik', 'tanzanian', 'thai', 'togolese', 'tongan', 'trinidadian or tobagonian', 'tunisian', 'turkish', 'tuvaluan', 'ugandan', 'ukrainian', 'uzbekistani', 'venezuelan', 'vietnamese', 'welsh', 'yemenite', 'zambian', 'zimbabwean']

jersey_choice = ['home', 'away']

options = ['a','b','c','d','e']

def chat_game():
    """Main function to run the Chat"""
    
    output = instructions()
    game =  True
    while game:
        
        # Gets first input from user: nationality
        team_name = input_team()
        if team_name == False:
            input_team()
        if team_name == None:
            print('\033[42m\033[1mWelp, you failed to select a nation, so here is a random one')
            team_name = random.choice(world_nations).capitalize()
            print('\033[41m\033[1mYou are the', team_name, 'team manager now, good luck')
 
        # Special game
        elif team_name == True:
            qs = special_game()
            
        # Ask user if they want to switch team
        team_change = change_team()
        if team_change == 'yes':
            input_team()
            print('JK you gotta stick to being the', team_name, 'manager, sucks to suck')
            
        # Asks user to input jersey preference and pairs them with opponent
        jersey = input_jersey()
        while jersey == False:
            input_jersey()
            break
        if jersey == False:
            print('\033[42m\033[1malright you failed to choose so you are home')
            jersey = 'home'
        jersey = side(jersey)
    
        # First game if user chooses 'home'
        if jersey == 'home':
            q1, q2, q3 = first_game()
            print('\033[44m\033[1mYou will now play the second team: SHPE FC')
            second_game()
            
        # Second game, reverses order if user chooses 'away'
        else:
            q1, q2, q3 = second_game()
            print('\033[44m\033[1mYou will now play the second team: Trap United')
            first_game()
            
        print('\033[43m\033[1mGood job, you won both games, you are now the best in the world!! thanks for playing')
        
        break
